package com.learning.learningapp2022.ganeshhegde.recyclerview

data class Planets(
val name:String,
val radius_km : Long)
