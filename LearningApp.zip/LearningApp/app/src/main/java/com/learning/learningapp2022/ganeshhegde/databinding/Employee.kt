package com.learning.learningapp2022.ganeshhegde.databinding

data class Employee(
 var id : Int,
 var name: String,
 var email : String
)
