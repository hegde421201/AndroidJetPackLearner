package com.learning.learningapp2022.ganeshhegde.coroutines

data class User(val id: Int,val name : String)