package com.learning.learningapp2022.ganeshhegde.coroutines.lifecycledemo

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class LifeCycleScopeActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


    }

}